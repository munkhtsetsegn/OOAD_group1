package lab6;
import java.util.Scanner;

public class Display {


    public static void main(String[] args) {
        Vaccine v1 = new Vaccine("Mongolia","mongol2021",150000,"100c","deglem barih heregtei","no alcohol");
        Vaccine v2 = new Vaccine("Russian","Russian2021",200000,"50c","deglem barih heregtei","no alcohol");
        Vaccine v3 = new Vaccine("China","China2021",100000,"70c","deglem barih heregtei","no alcohol");
        v1.displayy();
        medicine m1 = new medicine("taria",100000,"70c","no alcohol");
        people [] obj = new people[10];
        int i=0;
        while(true){
            if(i==0){
                System.out.println("hereglegch alga!!!!");
            }else{
                for(int j=0;j<i;j++){
                    obj[j].print();
                    if(obj[j].isVaccine){
                        if(v1.getName().equals(obj[j].getVaccineName())) {
                            System.out.println("Zuwulguu: "+ v1.getAdvice());
                            System.out.println("Rules: " + v1.getRules());
                        }
                        else if(v2.getName().equals(obj[j].getVaccineName())) {
                            System.out.println("Zuwulguu: " + v2.getAdvice());
                            System.out.println("Rules: " + v2.getRules());
                        }
                        else {
                            System.out.println("Zuwulguu: " + v3.getAdvice());
                            System.out.println("Rules: " + v3.getRules());
                        }
                    }
                    else System.out.println("Rules: "+m1.getRules());

                    System.out.println("----------!!!!--------");
                }
            }
            int sw=0;
            Scanner in = new Scanner(System.in);
            obj[i] = new people();
            System.out.println("owgoo oruul: ");
            obj[i].setLname(in.nextLine());
            System.out.println(obj[i].getLname());
            System.out.println("neree oruul: ");
            obj[i].setFname(in.nextLine());
            System.out.println(obj[i].getFname());
            System.out.println("toog songo taria: 1 vaccine: 2");
                    sw = in.nextInt();
                    switch (sw) {
                        case 1: obj[i].isMedicine=true ;
                            break;

                        case 2: obj[i].isVaccine = true;
                            break;
                        default: ;
                            break;
                    }
                    if(sw==2){
                        System.out.println("Yamar vaccine songoh we?");
                        System.out.println("------111111111------");
                        v1.displayy();
                        System.out.println("------222222222------");
                        v2.displayy();
                        System.out.println("------333333333------");
                        v3.displayy();
                        switch(in.nextInt()){
                                case 1: obj[i].setVaccineName(v1.getName());
                                    break;
                                case 2:
                                    obj[i].setVaccineName(v2.getName());
                                    break;
                                case 3:
                                    obj[i].setVaccineName(v3.getName());
                                    break;
                                default:;
                                    break;
                        }
                    }
        i++;
        }
    }
}

