package lab6;

public class Country {
        String countrynName= "mongolia";

  public Country(String countrynName){
       this.countrynName = countrynName;
   }
    void displayy(){
        System.out.println("country: "+this.getCountrynName());
    }
    public String getCountrynName() {
        return countrynName;
    }

    public void setCountrynName(String countrynName) {
        this.countrynName = countrynName;
    }
}
