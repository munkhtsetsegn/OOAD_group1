package lab6;
import java.util.Scanner;

public class Display {


    public static void main(String[] args) {
        Vaccine v1 = new Vaccine("Mongolia","mongolvaccine",75000,"30c","deglem barih","us hvrgej bolohgvi");
        Vaccine v2 = new Vaccine("Russian","Russianvaccine",65000,"240c","deglem barih","ydarj bolohgvi");
        Vaccine v3 = new Vaccine("China","Chinavaccine",45000,"32c","deglem barih","daarj bolohgvi");
        v1.displayy();
        Medicine m1 = new Medicine("taria",25000,"30c","no alcohol");
        People [] obj = new People[10];
        int i=0;
        while(true){
            if(i==0){
                System.out.println("hereglegch oldsongvi!!!!");
            }else{
                for(int j=0;j<i;j++){
                    obj[j].print();
                    if(obj[j].isVaccine){
                        if(v1.getName().equals(obj[j].getVaccineName())) {
                            System.out.println("Zuwulguu: "+ v1.getAdvice());
                            System.out.println("Rules: " + v1.getRules());
                        }
                        else if(v2.getName().equals(obj[j].getVaccineName())) {
                            System.out.println("Zuwulguu: " + v2.getAdvice());
                            System.out.println("Rules: " + v2.getRules());
                        }
                        else {
                            System.out.println("Zuwulguu: " + v3.getAdvice());
                            System.out.println("Rules: " + v3.getRules());
                        }
                    }
                    else System.out.println("Rules: "+m1.getRules());

                    System.out.println("----------!!!!--------");
                }
            }
            int sw=0;
            Scanner in = new Scanner(System.in);
            obj[i] = new People();
            System.out.println("Tanii owog: ");
            obj[i].setLname(in.nextLine());
            System.out.println(obj[i].getLname());
            System.out.println("Tanii ner: ");
            obj[i].setFname(in.nextLine());
            System.out.println(obj[i].getFname());
            System.out.println("Toogoo oruulna uu taria: 1 vaccine: 2");
                    sw = in.nextInt();
                    switch (sw) {
                        case 1: obj[i].isMedicine=true ;
                            break;

                        case 2: obj[i].isVaccine = true;
                            break;
                        default: ;
                            break;
                    }
                    if(sw==2){
                        System.out.println("Ali vaccine songoh we?");
                        System.out.println("------11------");
                        v1.displayy();
                        System.out.println("------22------");
                        v2.displayy();
                        System.out.println("------33------");
                        v3.displayy();
                        switch(in.nextInt()){
                                case 1: obj[i].setVaccineName(v1.getName());
                                    break;
                                case 2:
                                    obj[i].setVaccineName(v2.getName());
                                    break;
                                case 3:
                                    obj[i].setVaccineName(v3.getName());
                                    break;
                                default:;
                                    break;
                        }
                    }
        i++;
        }
    }
}

