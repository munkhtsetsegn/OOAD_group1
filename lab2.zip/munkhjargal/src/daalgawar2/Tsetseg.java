package daalgawar2;
import java.util.*;

class Munkhjargal{
	String name;
	String country;
	String color ;
	String type;
	public Munkhjargal(String name, String country) {
		this.name = name;
		this.country= country;

	}
	public void pr() {
		System.out.println("name: " + name + " country " + country);
	}
}
class Sarnai extends Munkhjargal{
	public Sarnai (String type, String name, String country, String color) {
		super(name,country);
		this.color = color;
		this.type = type;
	}
	public void pr() {
		System.out.println("country: " + country + "type: " + type + "\tname: " + name +   "\tcolor: " + color);
	}
}

class Centifolia extends Munkhjargal{
	public Centifolia(String type, String name, String country, String color) {
		super(name, country);
		this.color = color;
		this.type = type;
	}
	public void pr() {
		System.out.println("country: " + country + "type: " + type +"\tname: " + name + "\tcolor: " + color);
	}
}
class Bourbon  extends Munkhjargal{
	public Bourbon (String type, String name, String country, String color) {
		super(name, country);
		this.color = color;
		this.type = type;
	}
	public void pr() {
		System.out.println("country: " + country + "type: " + type + "\tname: " + name + "\tcolor: " + color);
	}
}
class Alba extends Munkhjargal{
	public Alba(String type, String name, String country, String  color) {
		super(name, country);
		this.color = color;
		this.type = type;
	}
	public void pr() {
		System.out.println("country: " + country + "type: " + type + "\tname: " + name +  "\tcolor: " + color);
	}
}
class Polyantha extends Munkhjargal{
	public Polyantha(String type, String name,String country, String color) {
		super(name, country);
		this.color = color;
		this.type = type;
	}
	public void pr() {
		System.out.println("country: " + country + "type: " + type + "\tname: " + name + "\tcolor: " + color);
	}
}
public class Tsetseg{
	public static void main(String[] args) {
		Munkhjargal a = new Sarnai("Park", "Iceberg", "NewZeland",  "white");
		Munkhjargal c = new Sarnai("Park", "Darby", "NewIrland",  "purple");
		Munkhjargal d = new Sarnai("Park", "Harkness", "NewAustrali", "pink");
		Munkhjargal e= new Sarnai("Park", "Renaiss", "NewMex",  "yellow");
		Munkhjargal f = new Sarnai("Park", "Blaze", "Irland" ,"orange");
		Munkhjargal g = new Sarnai("Park", "Sunset", "China", "brown");
		Munkhjargal h = new Centifolia("Garden", "Beauty", "newyork", "blue");
		Munkhjargal i = new Centifolia("Garden", "Queen", "Golland", "orange");
		Munkhjargal j = new Centifolia("Garden", "Elizabeth", "Russia", "rosegold");
		Munkhjargal k = new Centifolia("Garden", "Avon", "German",  "pink");
		Munkhjargal l = new Centifolia("Garden", "Carpet", "Korea", "white");
		Munkhjargal m = new Centifolia("Garden", "Coral", "Japan", "green");
		Munkhjargal n = new Bourbon ("Tea", "Charles", "Australia",  "red");
		Munkhjargal o = new Bourbon ("Tea", "Gualle", "Bahamas", "yelow");
		Munkhjargal p = new Bourbon ("Tea", "Sugarbaby", "Azerbaijan",  "yellow");
		Munkhjargal q = new Bourbon ("Tea", "De", "Bangladesh",  "red");
		Munkhjargal r = new Bourbon ("Tea", "Venus", "Belgium", "pink");
		Munkhjargal s = new Bourbon ("Tea", "theFairy", "Brazil",  "red");
		Munkhjargal t = new Alba("Rambling", "Mollineux", "Brazil",  "black");
		Munkhjargal u = new Alba("Rambling", "Kifts", "Brazil",  "pink");
		Munkhjargal v = new Alba("Rambling", "Gate", "Bulgaria",  "white");
		Munkhjargal w = new Alba("Rambling", "Pillar", "Colombia", "pink");
		Munkhjargal x = new Alba("Rambling", "bunner", "Congo", "red");
		Munkhjargal y = new Alba("Rambling", "Swany", "Egypt",  "yellow");
		Munkhjargal z = new Polyantha("Shrub", "Plena", "Georgia",  "pink");
		Munkhjargal ro = new Polyantha("Shrub", "Blush", "Colombia",  "red");
		Munkhjargal ros = new Polyantha("Shrub", "Semi", "Georgia",  "violet");
		Munkhjargal rose = new Polyantha("Shrub", "Louise", "Congo",  "red");
		Munkhjargal rosie = new Polyantha("Shrub", "Odier", "Greece",  "red");
		Munkhjargal roses = new Polyantha("Shrub", "Bullata", "Congo",  "orange");
        
		
		
		ArrayList<Munkhjargal> Object = new ArrayList<Munkhjargal>();
		Object.add(a);
		Object.add(c);
		Object.add(d);
		Object.add(e);
		Object.add(f);
		Object.add(g);
		Object.add(h);
		Object.add(i);
		Object.add(j);
		Object.add(k);
		Object.add(l);
		Object.add(m);
		Object.add(n);
		Object.add(o);
		Object.add(p);
		Object.add(q);
		Object.add(r);
		Object.add(s);
		Object.add(t);
		Object.add(u);
		Object.add(v);
		Object.add(w);
		Object.add(x);
		Object.add(y);
		Object.add(z);
		Object.add(ro);
		Object.add(ros);
		Object.add(rose);
		Object.add(rosie);
		Object.add(roses);
        
		
		for(Munkhjargal b:Object) {
			b.pr();
		}
	}
}