package lab5;

/*
Zochid buudliin baiguulagch funkts
*/
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Simulation {
private static String readLine() {
  BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
  try {
    return stdin.readLine();
  } catch (Exception e) {
    System.out.println("Invalid Input");
  }
  return null;
}
/**
 *gol funts.
 */
public static void main(String[] args) {
  //zochid buudlaa baiguulah
  Hotel hotelObj = new Hotel();
  //tur hugatsaanii huwsagch ashiglasan
  String name;
  String num;
  int roomnum;
  //undsen durem
  while (true) {
    //delgetsruu garah heseg
    System.out.print("Uildel: ");
    System.out.flush();
    //ugugdluu oruulna
    String command = readLine();
    //hereglegchiig delgets ruu gargana
    if ((command == null) || command.equalsIgnoreCase("quit")) {
      System.out.println("Good bye");
      break;
    }
    //uruuguu hadgalah
    if (command.equalsIgnoreCase("reserve")) {
      //ner hadgalah
      System.out.print("Name: ");
      System.out.flush();
      name = readLine();
      roomnum = -1;
      //urdchilan zahialga ugsun bol uruuguu shuud avna
      if (!((name == null) || (name.equals("")))) {
        roomnum = hotelObj.reserveRoom(name);
      }
      //sanal huselt ugnu
      if (roomnum == -1) {
        System.out.println("No reservation for you!");
      } else {
        System.out.println(name + " reserved room " + roomnum);
      }
    }
    //todorhoi uruu zahialna
    if (command.equalsIgnoreCase("reserveN")) {
      //ner uruunii dugaar asuuna
      System.out.print("Name: ");
      System.out.flush();
      name = readLine();
      System.out.print("Room number: ");
      System.out.flush();
      num = readLine();
      //if we got a bad input, report failure
      if ((name == null) || (name.equals("")) || (num == null)) {
        roomnum = -1;
      } else {
        //String turluu int bolgon uurchluh aldaa gaarah magadlaltai
        try {
          roomnum = Integer.parseInt(num);
        } catch (Exception e)  {
          roomnum = -1;
        }
      }
      //sanal huseltee uguh
      if (!hotelObj.reserveRoom(name, roomnum)) {
        System.out.println("No reservation for you!");
      } else {
        System.out.println(name + " reserved room " + roomnum);
      }
    } else if (command.equalsIgnoreCase("cancel")) {
      //ner asuuh
      System.out.print("Name: ");
      System.out.flush();
      name = readLine();
      //urdchilan zahialga baihgui bol tsutslagdana
      if (!((name == null) || (name.equals("")))) {
        hotelObj.cancelReservations(name);
        System.out.println(name + " now has no reservations.");
      } else {
        System.out.println("Who?");
      }
    } else if (command.equalsIgnoreCase("print")) {
      hotelObj.printReservations();
    } else if (command.equalsIgnoreCase("build")) {
      //dugaar asuuna
      System.out.print("How many: ");
      System.out.flush();
      num = readLine();
      //int ruu hurwuulne
      roomnum = -1;
      if (num != null) {
        try {
          roomnum = Integer.parseInt(num);
        } catch (Exception e) {
          roomnum = -1;
        }
      }
    //uruund nemne
      if (hotelObj.buildRooms(roomnum)) {
        System.out.println("Added " + roomnum + " more rooms");
      } else {
        System.out.println("No more rooms for you");
      }
    } else {
      System.out.println("Bolomjtoi uildluud :");
      System.out.println("print - buh zahialgiig haruulah");
      System.out.println("reserve - zochid buudald zahialga uguh");
      System.out.println("reserveN - todorhoi uruu zahialah");
      System.out.println("cancel - zahialgaa tsutslah");
      System.out.println("build - zochid buudal uruuguu sullah");
    }
  }
}
}