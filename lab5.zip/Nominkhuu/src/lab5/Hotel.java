package lab5;
/*
Uruu zahialj bolno zahialgaa tsutsalj bolno uruu nemj bolno ali uruund hun baigaa haradagdah
*/
import java.util.ArrayList;

public class Hotel{
//odoogiin zahialgiig hynan
private ArrayList<Reservation> rooms;
private int rnum = 1;
//ali unuunuus ehlehiig zaaj ugnu
//anh 5 uruutei bn
Reservation reserveObj;

/**
 *Baiguulagch.
 */
public Hotel() {
  rooms = new ArrayList<Reservation>();
  rooms.ensureCapacity(5);
  for (int i = 0; i < 5; i++) {
    rooms.add(null);
  }
}

/**
 *Baiguulagch.
 */
public Hotel(int numRooms) {
  rooms = new ArrayList<Reservation>();
  rooms.ensureCapacity(numRooms);
  for (int i = 0; i < numRooms; i++) {
    rooms.add(null);
  }
}

//zochid buudaldaa iluu olon uruu nemj amjiltand hurne 
/**
 *uruu zahialah arga.
 */
public boolean buildRooms(int num) {
  //parametr huchintei esehiig shalgah
  if (num <= 0) {
    return false;
  }
  //vectoriin huchin chadliig nemegduulah
  rooms.ensureCapacity(rooms.size() + num);
  for (int i = 0; i < num; i++) {
    rooms.add(null);
  }
  //tailan amjilttai bna
  return true;
}

//bolomjtoi uruuguu nuutsluudbutsaaj gargana
//zahialga duuren bval -1 butsaana
/**
 *method for reserve room.
 */
public int reserveRoom(String person) {
  for (int i = 0; i < rooms.size(); i++) {
    if (rooms.get(i) == null) {
      reserveObj = new Reservation(person);
      reserveObj.setRoom(rnum);
      rooms.set(i,reserveObj);
      rnum++;
      return rnum - 1;
    }
  }
  return -1;
}

//reserves a particular room for this person
//returns false on failure (eg. room is already reserved)
/**
 *hun uruunii dugaar zahialga heseg.
 */
public boolean reserveRoom(String person, int roomNum) {
  try {
    if (rooms.get(roomNum - 1) == null) {
      reserveObj = new Reservation(person,roomNum);
      rooms.set(roomNum  - 1,reserveObj);
      rnum++;
      return true;
    }
  } catch (Exception vb) {
    return false;
  }
  return false;
}
//cancels all reservations by this person
/**
 *Uruunii zahialga tsutslagdana.
 */
public void cancelReservations(String person) {
  for (int i = 0; i < rooms.size(); i++) {
    if (rooms.get(i) != null) {
      if (rooms.get(i).getName().equals(person)) {
        rooms.set(i,null);
      }
    }
  }
}

//odoo baigaa zahialguudaa delgets ruu hewlene
//mun niit zahialga sul uruug haruulna
/**
 *Zahialgaa hewleh.
 */
public void printReservations() {
  for (int i = 0; i < rooms.size(); i++) {
    if (rooms.get(i) != null) {
      System.out.println(rooms.get(i));  
    } else {
      System.out.println((i + 1) + " is not reserved");
    }
  }
}
}