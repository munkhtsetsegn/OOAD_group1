package lab5;

/*
Zahialah hun zochid buudal uruunii dugaariig hadgaldag funkts
*/

public class Reservation{
//instance variables
private String name;
private int roomNumber;

//neree hadgalj uguud songoltoor uruuguu songono
public Reservation(String person) {
  name = person;
}

public Reservation(String person, int room) {
  name = person;
  roomNumber = room;
}

//uruunii dugaar eswel neriig tohiruulna
public void setRoom(int newroom) {
  roomNumber = newroom;
}

public void setName(String newname) {
  name = newname;
}

public String toString() {
  return (name + "   " + roomNumber);
}

//newterch uruunii dugaar bolon neriig butsaan haruulna
public int getRoom() {
  return roomNumber;
}

public String getName() {
  return name;
}
}

